#include<iostream>
#include"dungeonCombat.h"
#include"player.h"
#include"ascii.h"

int main (){
    std::string pName;
    int pMaxHealth = 150, pAtk = 15, pCoins= 10, pLvl = 1, pExp = 0, pChoice, highestDungeonCleared = 0;
    int pHealth = pMaxHealth;
    bool gameRun=1;

    system("color 0C");
    printTitle();                                                                                

    std::cout << "\n\nWelcome to Dumbgeon, the dumbest dungeon game ever made (citation required).";
    
    while(gameRun) 
    {
        printDashboard(pHealth, pMaxHealth, pCoins);
        std::cout << "\n-----------\nWhere do you want to go next?\n1. Dungeons\n2. Store\n3. Exit\n";
        
        std::cin >> pChoice;
        
        
        switch (pChoice) {
            
            case 1: 
                {
                    if (pHealth <= 0) {
                        std::cout << "Eh, I don't think you should be fighting in that state... go heal up.";
                        break;
                    }
                    int i, dungeonLevel;
                    std::cout << "\nWhich dungeon do you want to go to?\n";
                    for (i=0; i<highestDungeonCleared+1;i++){
                        std::cout << "dungeon number " << i+1<< std::endl;
                    }
                    std::cin >> dungeonLevel;

                    if (dungeonLevel > 0 && dungeonLevel <= highestDungeonCleared+1) 
                    {
                        std::cout << "You are in dungeon " << dungeonLevel;
                        dungeon(&pHealth, &pMaxHealth, &pAtk, &pCoins, &pLvl, &pExp, dungeonLevel, &highestDungeonCleared);
                    } 
                    else if (dungeonLevel > highestDungeonCleared) 
                    {
                        std::cout << "This dungeon is too much for you.";
                    } 
                    else 
                    {
                        std::cout << "why are you trying to break my code";
                    }

                    break;
                }
            
            case 2:
                std::cout << "you are in store\n1. Buy health potion (3 coins)\n2. Leave";
                std::cin >> pChoice;
                
                switch (pChoice) {
                    case 1: 
                        std::cout << "Healed 100 health";
                        pHealth = pHealth + 100;
                        pCoins = pCoins - 3;
                        break;
                    case 2:
                        break;
                    default:
                        std::cout << "Sorry, we don't sell those.";
                        break;
                }
                break;
            
            case 3:
                gameRun=0;
                break;
            
            default:
                std::cout << "invalid input";
                break;
        }
    }
    
    return 0;
}