#include<iostream>
#include"ascii.h"

class Enemy 
{
    public:
    int health, drop, atk, maxHealth;
    
    Enemy () {

    }

    Enemy (int enemyNum, int dungeonLevel) {
        float modifier = (enemyNum * 10) + dungeonLevel;

        int base = rand() % 10; 

        health = base + modifier;
        maxHealth = health;
        drop = int32_t((base + modifier)/modifier);
        atk = modifier - base;
    }
    
    int* getHealth () 
	{
        return &health;
    }

    int getMaxHealth() {
        return maxHealth;
    }
    
    int getDrop () 
	{
        return drop;
    }
    
    int getAtk () 
	{
        return atk;
    }
    
    int attack(int* enemyHealth, int pAtk) 
	{
        *enemyHealth = *enemyHealth - pAtk;
        return *enemyHealth;
    }
};

void attackPlayer (Enemy enemy, int* pHealth) 
{
	*pHealth = *pHealth - enemy.getAtk();
}

int fight (int* pHealth, int pAtk, bool* enemyDefeated, Enemy* enemy1)
{
    int pChoice;

    std::cout << "\nEnemy health:\n";
    showHealth(*enemy1->getHealth(), enemy1->getMaxHealth());
    std::cout << "\nWhat do you want to do?\n1. Attack\n2. Flee\n";
    std::cin >> pChoice;
    
    switch (pChoice) {
        case 1:
            enemy1->attack(enemy1->getHealth(), pAtk);
            attackPlayer(*enemy1, pHealth);
            if (*pHealth <= 0) {
                return 2;
            }
            break;
            
        case 2:
            *enemyDefeated = true;
            break;
            
        default:
            std::cout << "\nERROR: Incorrect input.";
            break;
    }
    return 1;
}

void dungeon (int* pHealth, int* pMaxHealth, int* pAtk, int* pCoins, int* pLvl, int* pExp, int dungeonLevel, int* highestDungeonCleared) 
{   
    int i;
        
    for (i=1;i<9;i++) 
    {
        int enemyNum = i;
        Enemy enemy1(enemyNum, dungeonLevel);
        bool enemyDefeated = false;
        while (enemyDefeated == false)
        { 
            printDashboard(*pHealth, *pMaxHealth, *pCoins);
            if (*enemy1.getHealth() > 0)
            {
                if (fight(pHealth, *pAtk, &enemyDefeated, &enemy1) == 2)
                {
                    printDead();
                    return;
                } 
                else 
                {
                    std::cout << "Enemy attacks you. Your health is " <<*pHealth;
                }
            } 
            else 
            {
                printWin();
                *pCoins = *pCoins + enemy1.getDrop();
                break;
            }
        }
    }

    int enemyNum = 20;
    Enemy enemy1(enemyNum, dungeonLevel);
    bool enemyDefeated = false;
    while (enemyDefeated == false)
    { 
        printDashboard(*pHealth, *pMaxHealth, *pCoins);
        if (*enemy1.getHealth() > 0) {
            if (fight(pHealth, *pAtk, &enemyDefeated, &enemy1) == 2)
            {
                printDead();
                return;
            }
        } 
        else 
        {
            printWin();
            *pCoins = *pCoins + enemy1.getDrop();
            break;
        }
    }
    if (*highestDungeonCleared == dungeonLevel-1) {
        *highestDungeonCleared = *highestDungeonCleared+1;
        std::cout << "new dungeon unlocked";
    } else if (dungeonLevel-1 > *highestDungeonCleared) {
        std::cout  << "YOU CHEATED ME??? CRYING";
    } else {
        std::cout << "yeah waht";
    }

}
